import { NextFunction, Request, Response } from 'express';

export function createTour(req: Request, res: Response, next: NextFunction) {
	// check if token valid
	// then create tour in db
}
